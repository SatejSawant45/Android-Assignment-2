#Program to determine if object is also an instance of parent class

class Students:
    def __init__(self,name,roll_no):
        self.name=name
        self.roll_no=roll_no
        
class Marks(Students):
    pass

a=Marks("Rohit",12)
print(isinstance(a,Students))