#Program to create a child class that inherits from parent class

class Transport:
    def __init__(self,name,capacity):
        self.name=name
        self.capacity=capacity
        
    def fare(self):
        return self.capacity*100
        
class Vehicle(Transport):
    def fare(self):
        amt=super().fare()
        amt+=amt*10/100
        return amt
    
a=Vehicle("Bus",80)
print("The fare of bus is:",a.fare())