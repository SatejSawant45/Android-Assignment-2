#Program to create a child class that inherits from parent class

class Students:
    def __init__(self,name,roll_no):
        self.name=name
        self.roll_no=roll_no
        
    def student_marks(self,score):
        return f"The marks of {self.name} is {score}"
    
class Marks(Students):
    def student_marks(self, score=89):
        return super().student_marks(score=89)
    
a=Marks("Rahul",20)
print(a.student_marks())