#Program to create a class with instance attributes

class Students:
    def __init__(self,name,prn):
        self.name=name
        self.prn=prn
        
student=Students("Rachit",22610007)
print("Name=",student.name,"\nPRN=",student.prn)
