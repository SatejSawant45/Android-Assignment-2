#Program to create a class without any varuables and methods

class Vehicle:
    pass