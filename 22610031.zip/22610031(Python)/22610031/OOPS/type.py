#Program that check type of an object

class Students:
    def __init__(self,name,roll_no):
        self.name=name
        self.roll_no=roll_no
        
class Marks(Students):
    pass

a=Marks("Rohit",12)
print("The type of class 'Marks' is:",type(a))