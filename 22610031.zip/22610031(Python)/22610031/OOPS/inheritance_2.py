#Program that must have same value for every class instance

class Students:
    name="Rohit"
    
    def __init__(self,subject,score):
        self.subject=subject
        self.score=score
        
class A(Students):
    pass

class B(Students):
    pass

x=A("Maths",88)
print("Name=",x.name,"\nSubject=",x.subject,"\nMarks=",x.score)
print("\n")
y=B("English",90)
print("Name=",y.name,"\nSubject=",y.subject,"\nMarks=",y.score)