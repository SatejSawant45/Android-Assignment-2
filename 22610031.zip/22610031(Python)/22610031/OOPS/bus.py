#Program to create a child class that will inherit all the variables and methods of parent class

class Vehicle:
    def __init__(self,name,speed,price):
        self.name=name
        self.speed=speed
        self.price=price
        
class Bus(Vehicle):
    pass

a=Bus("School Bus",140,120000)
print("Vehicle Name=",a.name,"\nMaximum speed=",a.speed,"km/hr","\nPrice=Rs",a.price)