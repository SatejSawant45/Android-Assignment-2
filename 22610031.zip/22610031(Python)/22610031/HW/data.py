#Program to create list with student data and retrieved the student data

class Student:
    def __init__(self,name,roll_no,grade):
        self.name=name
        self.roll_no=roll_no
        self.grade=grade

class Data:
    def __init__(self):
        self.students=[]
    

    def add(self,student):
        self.students.append(student)

    def retrive(self):
        if not self.students:
            print("No data available")
        else:
            print("Student Data:")
            for student in self.students:
                print(f"Name:{student.name}")
                print(f"Roll Number:{student.roll_no}")
                print(f"Grade:{student.grade}")
                print()

a=Data()
while True:
    print("\nOptions:")
    print("1.Add Data")
    print("2.Retrive Data")
    print("3.Quit")

    choice=int(input("Enter your choice:"))

    if choice==1:
        name=input("Enter student's name:")
        roll_no=int(input("Enter roll number:"))
        grade=input("Enter grade:")

        student=Student(name,roll_no,grade)
        a.add(student)
    elif choice==2:
        a.retrive()
    elif choice==3:
        break
    else:
        print("Invalid Choice")
