#Program to call method that doesn't appear object passed to method

class MyClass:
    varr="Hello World"

    def __init__(self,value):
        self.value=value

    def instance(self):
        print("This is an instance method")
        print("Value:",self.value)

    @staticmethod
    def static():
        print("This is a static method")
        print("You can call it without creating an instance")

    @classmethod
    def class_meth(cl):
        print("This is a class method.")
        print("It can access class variables, e.g.,", cl.varr)

obj=MyClass("Hi")

obj.instance()
MyClass.static()
MyClass.class_meth()