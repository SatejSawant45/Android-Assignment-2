#Program to display all position of substring in a given main stream

import numpy as np

def find(main,substring):
    pos=[]
    main=np.array(list(main))
    substring=np.array(list(substring))

    for i in range(len(main)-len(substring)+1):
        if np.array_equal(main[i:i+len(substring)],substring):
            pos.append(i)
    return pos

main=input("Enter main string:")
substring=input("Enter substring to search:")

pos=find(main,substring)

if pos:
    print(f"The substring '{substring}' was found at position:{pos}")
else:
    print(f"The substring '{substring}' was not found in the main string")

