#Program to solve tuple with nested tuple

import numpy as np
tup=(1,(2,3),4,(5,(6,7)))

def flat(tup):
    list=[]
    for item in tup:
        if isinstance(item,tuple):
            list.extend(flat(item))
        else:
            list.append(item)
    return np.array(list)

arr=flat(tup)

print("Flattened Array:",arr)
print("Sum of Elements:",np.sum(arr))
print("Mean of Elements:",np.mean(arr))
