#Program to except two Matrix and return the product of them

import numpy as np
a=np.random.random((5,3))
b=np.random.random((3,5))

product=np.dot(a,b)
print(product)