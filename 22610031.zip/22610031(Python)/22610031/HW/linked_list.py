#Program to create link list and performance operation

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

    def search(self, target):
        current = self.head
        while current:
            if current.data == target:
                return True
            current = current.next
        return False

    def delete(self, target):
        if not self.head:
            return

        if self.head.data == target:
            self.head = self.head.next
            return

        current = self.head
        while current.next:
            if current.next.data == target:
                current.next = current.next.next
                return
            current = current.next

my_list = LinkedList()

my_list.append(10)
my_list.append(20)
my_list.append(30)
my_list.append(40)

print("Linked List:")
my_list.display()

target = 20
if my_list.search(target):
    print(f"{target} found in the linked list.")
else:
    print(f"{target} not found in the linked list.")

target = 30
my_list.delete(target)
print(f"Deleted {target} from the linked list.")

print("Updated Linked List:")
my_list.display()
