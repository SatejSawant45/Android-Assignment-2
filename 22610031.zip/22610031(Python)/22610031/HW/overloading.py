#Program to implement overloading concept 

class OverloadingDemo:
    def example(self, *args):
        if len(args) == 1:
            print("Method with one argument:", args[0])
        elif len(args) == 2:
            print("Method with two arguments:", args[0], args[1])
        else:
            print("No matching method found for the given arguments.")

demo = OverloadingDemo()

demo.example(10)
demo.example(20, 30)
demo.example(40, 50, 60)
