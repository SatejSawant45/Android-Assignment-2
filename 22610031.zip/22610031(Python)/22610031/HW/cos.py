#Program find cosine value of given angle integrals by evaluating in cosine series

import numpy as np
a=np.array([0,np.pi/6,np.pi/4,np.pi/3,np.pi/2])
 
b=np.cos(a)
print("Angles:",a)
print("Cosine values:",b)
