#Program to find indices of non zero elements 

import numpy as np
x=np.array([1,2,0,0,4,0])
d=np.nonzero(x)
print(d)