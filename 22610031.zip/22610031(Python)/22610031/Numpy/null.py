#Program to create a null vector of size 10

import numpy as np
x=np.zeros(10)
print(x)