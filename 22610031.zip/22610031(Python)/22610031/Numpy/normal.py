#Program to create a 5x5 array with random values and normalize it row-wise.

import numpy as np
a=np.random.rand(5,5)

print("Original array:")
print(a)

norm_arr=a/np.linalg.norm(a,axis=1,keepdims=True)

print("Normalize Array row-wise:")
print(norm_arr)