#Program to create 8x8 matrix and fill it with a checkboard pattern

import numpy as np
a=np.ones((3,3),dtype=int)
print("Checkboard Pattern:")
a=np.zeros((8,8),dtype=int)
a[1::2,::2]=1
a[::2,1::2]=1
print(a)