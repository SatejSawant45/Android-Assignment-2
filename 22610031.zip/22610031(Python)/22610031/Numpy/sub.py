#Program to create a 3x3 array with random values and subtract the mean of each row from each element.

import numpy as np
a=np.random.rand(3,3)

print("Original array:")
print(a)

row=np.mean(a,axis=1,keepdims=True)
print("Mean of each row:")
print(row)

sub=a-row
print("Subtract the mean of each row from each element:")
print(sub)