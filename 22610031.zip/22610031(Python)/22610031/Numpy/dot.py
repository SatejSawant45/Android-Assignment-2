#Program to find the dot product of two arrays of different dimensions.

import numpy as np
a=np.array([[1,2],[3,4],[5,6]])
b=np.array([7,8])

print("Array 1:")
print(a)
print("Array 2:")
print(b)

res=np.dot(a,b)
print("Result is:")
print(res)