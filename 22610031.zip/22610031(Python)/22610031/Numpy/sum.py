#Program to create a 4x4 array with random values and find the sum of each row.

import numpy as np
a=np.random.rand(4,4)

row=np.sum(a,axis=1)

print("Original array:")
print(a)
print("Sum of each row:")
print(row)