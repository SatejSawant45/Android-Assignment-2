#Program to create a 5x5 array with random values and find the second-largest value in each row.

import numpy as np
a=np.random.rand(5,5)

print("Original array:")
print(a)

s=np.partition(a,-2,axis=1)[:,-2]

print("Second-largest value in each row:")
print(s)
