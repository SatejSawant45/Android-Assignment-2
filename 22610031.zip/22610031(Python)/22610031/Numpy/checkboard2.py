#Program to create a checkboard 8x8 matrix using tile function

import numpy as np
a=np.tile([[0,1],[1,0]],(4,4))
print("Checkboard Pattern:")
print(a)