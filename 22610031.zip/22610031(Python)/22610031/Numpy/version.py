#Program to print numpy version and configuration

import numpy as np
print(np.__version__)
print(np.show_config())