#Program to create a 2-D array with 1 on border and 0 inside

import numpy as np
a=np.ones((5,5),dtype=int)
print("Original array:",a)

print("1 in border and 0 on inside")
a[1:-1,1:-1]=0
print(a)