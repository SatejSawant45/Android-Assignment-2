#Program to find result of the following expression
'''
0 * np.nan
np.nan == np.nan
np.inf &gt; np.nan
np.nan - np.nan
np.nan in set([np.nan])
0.3 == 3 * 0.1
'''
import numpy as np

result=np.nan,False,False,np.nan,True,False

print(result)