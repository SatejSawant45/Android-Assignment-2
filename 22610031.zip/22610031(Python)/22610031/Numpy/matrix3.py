#Program to create 5x5 matrix with values 1,2,3,4 just below diagonal

import numpy as np
a=np.diag([1,2,3,4],k=-1)
print(a)