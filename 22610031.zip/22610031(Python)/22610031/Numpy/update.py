#Program to create a null vector size 10 and replace fifth value by 10

import numpy as np
x=np.zeros(10)
x[5]=1
print(x)