#Program to reverse a vector

import numpy as np
x=np.arange(10,49)
print("Original vector is:",x)
x=x[::-1]
print("Reversed vector is:",x)