#Program to create a 3x3x3 array with random values

import numpy as np
x=np.random.random((3,3,3))
print(x)