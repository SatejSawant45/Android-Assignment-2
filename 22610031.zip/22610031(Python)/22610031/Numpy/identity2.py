#Program to create a 3x3 identity matrix and stack it vertically and horizontally.

import numpy as np
a=np.identity(3,dtype=int)

print("Identity matrix:")
print(a)

ver=np.vstack((a,a,a))
hor=np.hstack((a,a,a))

print("Vertical Stack:\n", ver)
print("Horizontal Stack:\n", hor)