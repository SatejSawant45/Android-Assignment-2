#Program to create a 5x5 array with random values and sort each row.

import numpy as np
a=np.random.rand(5,5)

print("Original array:")
print(a)

sorted=np.sort(a,axis=1)

print("Sort each row of the said array:")
print(sorted)