#Program to consider a (6,7,8) shape array and find index (x,y,z) of 100th element

import numpy as np
a=np.unravel_index(99,(6,7,8))
print(a)