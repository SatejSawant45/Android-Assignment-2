#Program to find the memory size of any array 

import numpy as np
n=np.zeros((4,4))
print("%d bytes"%(n.size*n.itemsize))