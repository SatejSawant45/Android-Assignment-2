#Program to create a vector with values ranging from 10 to 49

import numpy as np
x=np.arange(10,49)
print("Vector is:",x)