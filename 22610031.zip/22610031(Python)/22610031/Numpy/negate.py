#Program to negate all elements which are between 3 and 8, in place.4

import numpy as np
a=np.array([1,2,3,4,5,6,7,8,9,10])
print("Original array:")
print(a)

a[(a>3)&(a<8)]*=-1
print("Modified array:")
print(a)