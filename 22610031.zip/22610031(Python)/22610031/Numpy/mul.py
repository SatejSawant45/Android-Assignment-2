#Program to multiply a 5x3 matrix by a 3x2 matrix

import numpy as np
a=np.random.random((5,3))
b=np.random.random((3,5))

product=np.dot(a,b)
print(product)