#Program to create a 5x5 array with random values and normalize it column-wise.

import numpy as np
print("Original matix:")
a=np.random.random((5,5))
print(a)

col=np.mean(a,axis=0)
print("Normalized matrix(colum wise):")
nor=(a-col)/np.std(a,axis=0)
print(nor)