#Program to normalize a 5x5 matrix

import numpy as np
print("Original matix:")
a=np.random.random((5,5))
print(a)

col=np.mean(a,axis=0)
print("Normalized matrix(colum wise):")
nor=(a-col)/np.std(a,axis=0)
print(nor)

