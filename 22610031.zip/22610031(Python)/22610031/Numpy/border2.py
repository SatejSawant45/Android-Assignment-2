#Program to add a border around an existing array

import numpy as np
a=np.ones((3,3),dtype=int)
print("Original array")
print(a)

print("0 in border and 1 on inside")
a=np.pad(a,pad_width=1,mode="constant",constant_values=0)
print(a)