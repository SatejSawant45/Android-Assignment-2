#Program to create a custom dtype that describes a color as four insigned bytes(RGBA)

import numpy as np
color=np.dtype([("R",np.ubyte),("G",np.ubyte),("B",np.ubyte),("A",np.ubyte)])
print(color)