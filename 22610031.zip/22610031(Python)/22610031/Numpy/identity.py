#Program to create a 3x3 identity matrix

import numpy as np
x=np.identity(3,dtype=int)
print(x)