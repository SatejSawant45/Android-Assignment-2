#Program to create a 10x10 array with random values and find minimum and maximum values

import numpy as np
x=np.random.random((10,10))
print(x)
max=x.max()
print("Maximum value is:",max)
min=x.min()
print("Minimum value is:",min)