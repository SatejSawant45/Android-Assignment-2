#Program to create a 5x5 array with random values and replace the minimum value with 0.

import numpy as np
a=np.random.rand(5,5)

print("Original array:")
print(a)

min=np.min(a)

a[a==min]=0

print("Array after replacing the maximum value with 0:")
print(a)