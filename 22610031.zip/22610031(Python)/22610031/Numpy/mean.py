#Program to create a random vector of size 30 and find the mean value

import numpy as np
x=np.random.random(30)
print(x)
c=np.mean(x)
print("Mean is:",c)