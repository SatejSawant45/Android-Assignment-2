#Program to create a 3x3x3 array with random values and find the sum along the last axis.

import numpy as np
a=np.random.rand(3,3,3)

print("Original array:")
print(a)

sum=np.sum(a,axis=2)
print("Sum along the last axis:")
print(sum)