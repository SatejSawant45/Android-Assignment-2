#Program to create a 3x3 array with random values and subtract the mean of each column from each element.

import numpy as np
a=np.random.rand(3,3)

print("Original array:")
print(a)

col=np.mean(a,axis=1)
print("Mean of each row:")
print(col)

sub=a-col
print("Subtract the mean of each row from each element:")
print(sub)