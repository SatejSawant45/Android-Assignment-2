import numpy as np
x=np.arange(0,9).reshape(3,3)
print(x)